//define

const form = document.querySelector('#task-form');
const tasklist=document.querySelector('.collections');
const clearBtn=document.querySelector('.clear-tasks');
const filter=document.querySelector('#filter');
const taskInput=document.querySelector('#task');

//load all event listeners

loadEventListeners();

function loadEventListeners(){
form.addEventListener('submit',addTask);

tasklist.addEventListener('click',removeTask);

clearBtn.addEventListener('click',clearTask);
}

//add task

function addTask(e){
    if(taskInput.value===''){
        alert("Add task");
    }

    const li = document.createElement('li');
    li.className='collection-item';
    li.appendChild(document.createTextNode(taskInput.value));
    const link = document.createElement('a');
    link.className='delete-item secondary-content';
    link.innerHTML='<i class="fas fa-trash-alt"></i>';
    li.appendChild(link);
    tasklist.appendChild(li);
    taskInput.value='';
   e.preventDefault();
}

function removeTask(e){
    if(e.target.parentElement.classList.contains('delete-item')){
        if(confirm('Are you sure?')){
        e.target.parentElement.parentElement.remove();
        }
    }
    
}

function clearTask(){
    tasklist.innerHTML='';

    // while(tasklist.firstChild){
    //     tasklist.removeChild(tasklist.firstChild);
    // }
}